
package tree;

/**
 *
 * @author EKUStudent
 */
class TreeNode{
    public String numb;
    public TreeNode left;
    
    public TreeNode right;
    public void disData() {
		System.out.println("{ " + numb + " } ");
	}
}
