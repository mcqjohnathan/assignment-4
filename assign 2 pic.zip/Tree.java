
package tree;

import java.util.Scanner;


public class Tree {

    
    public static void main(String[] args) {
        /*String sq[]= new String[15];
        sq[1] = "1";
        sq[2] = "2";
        sq[3] = "3";
        sq[4] = "4";
        sq[5] = "5";
        sq[6] = "6";
        sq[7] = "7";
        sq[8] = "8";
        sq[9] = "9";
        sq[10] = "10";
        sq[11] = "11";
        sq[12] = "12";
        sq[13] = "13";
        sq[14] = "14";*/
    Scanner in = new Scanner(System.in);
    System.out.println("Enter the length of your tree (for example [1, 2, 3 ,4 ,5 ,6 ,7, null, 8] would be 9)");
    int len = in.nextInt();
    len++;
    String sq[]= new String[len];
    for (int i = 1; i < len; i++) {
        System.out.println("Enter your "+i+" value:");
        String n = in.next();
        
        sq[i]=n;
    }
    
    

        
        YourSolution poo = new YourSolution();
        poo.init(sq,len);

            
        }
        
    }

