/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tree;

import java.util.Scanner;

/**
 *
 * @author EKUStudent
 */
public class YourSolution{
    int a = 1;
    private TreeNode root;
    public void init(  String [] sq, int len){
          TreeNode node = new TreeNode();
          node.numb = sq[1];
          root = node;
          preOrder2(node, 2,  sq,  len);

          
         System.out.println("Pre:");
         printpre(root); 
         System.out.println();
         System.out.println("Inorder:");
         printin(root);
         
    }
    
    
    
    private void printpre(TreeNode node) {
    if (node == null) {
      return;
    }
    String n = node.numb;
    
    if(n.charAt(0)!='n')
        System.out.printf("%s ", node.numb);
    printpre(node.left);
    printpre(node.right);
    }
    
    private void printin(TreeNode node) {
    if (node == null) {
      return;
    }
    printin(node.left);
     String n = node.numb;
    if(n.charAt(0)!='n')
        System.out.printf("%s ", node.numb);
    printin(node.right);
    
    
    
    }
    
    
    
    
    private void preOrder2(TreeNode node, int i, String [] sq, int len) {
    if (i >= len) {
      return;
    }
    TreeNode node2 = new TreeNode();
    TreeNode node3 = new TreeNode();
    String n = "1";
    
    
    node2.numb = sq[i];
    node.left= node2;
    if(i+1<len){
        n = sq[i+1];}
    
    if(i+1<len&&n.charAt(0)!='n'){
        node3.numb = sq[i+1];
        node.right= node3;}
    
        
        
        a++;
    //}
    
    preOrder2(node.left,2*i,sq,len);
    if(i+1<len&&n.charAt(0)!='n')
        preOrder2(node.right,2*(i+1),sq,len);
    }

}