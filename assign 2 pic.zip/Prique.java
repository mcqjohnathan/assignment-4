/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prique;


import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;


public class Prique {


    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue();
        Scanner in = new Scanner(System.in);
        
        System.out.println("How big is your first singly linked list");
        int len = in.nextInt();
        System.out.println();
        int sq[]= new int[len]; 
        System.out.println("Enter your first number");
        int a = in.nextInt();
        sq[0]=a;
        
        int pos=1;
        while (len>pos){
            System.out.println("Enter your next number");
            a = in.nextInt();
            sq[pos]=a;
            
            pos++;
        }
        pos=0;
        while( pos<len){
            pq.add(sq[pos]);
            pos++;
        }
        pos=0;
        while(pos<len){
            sq[pos]=(int) pq.remove();
            pos++;
        }
        pos=0;
        System.out.println("Your sequence ordered is");
        while(pos<len){
            int b=sq[pos];
            System.out.println(b);
            pos++;
        }
        /*System.out.println("");
        
        System.out.println(pq.remove());
        System.out.println(pq.remove());
        System.out.println(pq.remove());*/
        
    }
}




